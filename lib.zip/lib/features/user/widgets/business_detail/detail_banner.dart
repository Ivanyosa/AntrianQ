import 'package:flutter/material.dart';

import '../../../../core/constants/app_radius.dart';
import '../../../../core/constants/app_shadow.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_style.dart';

import 'status_badge.dart';

class DetailBanner extends StatelessWidget {
  final String name;
  final String status;

  const DetailBanner({super.key, required this.name, required this.status});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 180,

      width: double.infinity,

      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(AppRadius.xl),

        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.primary, Color(0xff8B5CF6)],
        ),

        boxShadow: AppShadow.soft,
      ),

      child: Stack(
        children: [
          Positioned(
            right: -20,
            bottom: -20,
            child: Icon(
              Icons.storefront,
              size: 150,
              color: Colors.white.withValues(alpha: .08),
            ),
          ),

          Padding(
            padding: const EdgeInsets.all(24),

            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,

              mainAxisAlignment: MainAxisAlignment.end,

              children: [
                Text(
                  name,
                  style: AppTextStyles.heading2.copyWith(color: Colors.white),
                ),

                const SizedBox(height: 12),

                StatusBadge(status: status),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
